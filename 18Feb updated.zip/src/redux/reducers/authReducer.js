// it is used to hold and manipulate the user related states in store.
// all auth related operations / user related operaations like  register , login  , loading current user info. etc.
const initialState = {
token : null,
isAuthenticated: null,
loading:true,
user:null
}
// it will be part of ur global state / store where we can hold all user related data.


export default (state = initialState, action) => {
    // action will share the data needs to be manipulated and it will share the flag
  switch (action.type) {

  case typeName:
    return { ...state }

  default:
    return state
  }
}
