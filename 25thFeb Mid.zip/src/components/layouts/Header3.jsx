import React from "react";
import PropTypes from "prop-types";

const Header3 = (props) => {
  return <div>Header3{props.appName}</div>;
};

Header3.propTypes = {};

export default Header3;
