import React, { Component } from "react";

export default class Login extends Component {
  render() {
    return <>Login</>;
  }
}
